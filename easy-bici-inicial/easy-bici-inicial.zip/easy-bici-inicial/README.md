# Requisitos para correr

- Tener MongoDB instalado
- Correr antes "npm install"

# Para ejecutar

- Correr "npm run devstart" o "npm run start"

# Para correr las pruebas

- Correr "npm run mochatest"
